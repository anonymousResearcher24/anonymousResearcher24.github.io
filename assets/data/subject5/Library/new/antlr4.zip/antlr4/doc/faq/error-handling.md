# Error handling

## How do I perform semantic checking with ANTLR?

See [How to implement error handling in ANTLR4](http://stackoverflow.com/questions/21613421/how-to-implement-error-handling-in-antlr4/21615751#21615751).
